<?php
echo "<input ".$classeStr." ".$evento." type=\"password\" id=\"".$nome."\" name=\"".$nameForm."\" value=\"".$valoreVero."\" />";
echo "<input ".$classeStr." ".$evento." type=\"hidden\" id=\"".$nome."_precedente\" name=\"".$nameForm."_precedente\" value=\"".$valoreVero."\" />";
?>
