<?php
if ($valoreVero != '') {
	$valore = $valoreVero;
}
echo "<input " . $classeStr . " " . $evento . " type=\"text\" name=\"" . $nameForm . "\" id=\"" . $nome . "\" value=\"" . $valore . "\" />";
?>
