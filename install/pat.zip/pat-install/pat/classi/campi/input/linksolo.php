<?php
if ($valoreVero != '') {
	$valore = $valoreVero;
}
echo "<input " . $classeStr . " " . $evento . " type=\"text\" name=\"" . $nome . "\" id=\"" . $nome . "\" value=\"" . $valore . "\" />";
// inserisco pulsante di apertura link
?>
