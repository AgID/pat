﻿/*
Copyright (c) 2003-2009, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.dialog.add( 'cellProperties', function( editor )
	{
		var langTable = editor.lang.table;
		var langCell = langTable.cell;
		var langCommon = editor.lang.common;
		var validate = CKEDITOR.dialog.validate;
		var widthPattern = /^(\d+(?:\.\d+)?)(px|%)$/,
			heightPattern = /^(\d+(?:\.\d+)?)px$/;
		var bind = CKEDITOR.tools.bind;

		function spacer()
		{
			return { type : 'html', html : '&nbsp;' };
		}

		return {
			title : langCell.title,
			minWidth : 480,
			minHeight : 140,
			contents : [
				{
					id : 'info',
					label : langCell.title,
					accessKey : 'I',
					elements :
					[
						{
							type : 'hbox',
							widths : [ '45%', '10%', '45%' ],
							children :
							[
								{
									type : 'vbox',
									padding : 0,
									children :
									[
										{
											type : 'hbox',
											widths : [ '70%', '30%' ],
											children :
											[
												{
													type : 'text',
													id : 'width',
													label : langTable.width,
													widths : [ '71%', '29%' ],
													labelLayout : 'horizontal',
													validate : validate[ 'number' ]( langCell.invalidWidth ),
													setup : function( selectedCell )
													{
														var widthMatch = widthPattern.exec( selectedCell.$.style.width );
														if ( widthMatch )
															this.setValue( widthMatch[1] );
													},
													commit : function( selectedCell )
													{
														var unit = this.getDialog().getValueOf( 'info', 'widthType' );
														if ( this.getValue() !== '' )
															selectedCell.$.style.width = this.getValue() + unit;
														else
															selectedCell.$.style.width = '';
													},
													'default' : ''
												},
												{
													type : 'select',
													id : 'widthType',
													labelLayout : 'horizontal',
													widths : [ '0%', '100%' ],
													label : '',
													'default' : 'px',
													items :
													[
														[ langTable.widthPx, 'px' ],
														[ langTable.widthPc, '%' ]
													],
													setup : function( selectedCell )
													{
														var widthMatch = widthPattern.exec( selectedCell.$.style.width );
														if ( widthMatch )
															this.setValue( widthMatch[2] );
													}
												}
											]
										},
										spacer(),
										{
											type : 'select',
											id : 'wordWrap',
											labelLayout : 'horizontal',
											label : langCell.wordWrap,
											widths : [ '50%', '50%' ],
											'default' : 'yes',
											items :
											[
												[ langCell.yes, 'yes' ],
												[ langCell.no, 'no' ]
											],
											commit : function( selectedCell )
											{
												if ( this.getValue() == 'no' )
													selectedCell.setAttribute( 'noWrap', 'nowrap' );
												else
													selectedCell.removeAttribute( 'noWrap' );
											}
										},
										spacer()
									]
								},
								spacer(),
								{
									type : 'vbox',
									padding : 0,
									children :
									[
										{
											type : 'select',
											id : 'cellType',
											label : langCell.cellType+' (Scope)',
											labelLayout : 'horizontal',
											widths : [ '50%', '50%' ],
											'default' : 'td',
											items :
											[
												[ langCell.data, 'td' ],
												[ langCell.header, 'th' ]
											],
											setup : function( selectedCell )
											{
												this.setValue( selectedCell.getName() );
											},
											commit : function( selectedCell )
											{
												selectedCell.renameNode( this.getValue() );
											}
										},
										spacer(),
										{
											type : 'text',
											id : 'rowSpan',
											label : langCell.rowSpan,
											labelLayout : 'horizontal',
											widths : [ '50%', '50%' ],
											'default' : '',
											validate : validate.integer( langCell.invalidRowSpan ),
											setup : function( selectedCell )
											{
												this.setValue( selectedCell.getAttribute( 'rowSpan' ) || '' );
											},
											commit : function( selectedCell )
											{
												if ( this.getValue() )
													selectedCell.setAttribute( 'rowSpan', this.getValue() );
												else
													selectedCell.removeAttribute( 'rowSpan' );
											}
										},
										{
											type : 'text',
											id : 'colSpan',
											label : langCell.colSpan,
											labelLayout : 'horizontal',
											widths : [ '50%', '50%' ],
											'default' : '',
											validate : validate.integer( langCell.invalidColSpan ),
											setup : function( selectedCell )
											{
												this.setValue( selectedCell.getAttribute( 'colSpan' ) || '' );
											},
											commit : function( selectedCell )
											{
												if ( this.getValue() )
													selectedCell.setAttribute( 'colSpan', this.getValue() );
												else
													selectedCell.removeAttribute( 'colSpan' );
											}
										}
									]
								}
							]
						}
					]
				}
			],
			onShow : function()
			{
				this.cells = CKEDITOR.plugins.tabletools.getSelectedCells(
					this._.editor.getSelection() );
				this.setupContent( this.cells[ 0 ] );
			},
			onOk : function()
			{
				var cells = this.cells;
				for ( var i = 0 ; i < cells.length ; i++ )
					this.commitContent( cells[ i ] );
			}
		};
	} );
